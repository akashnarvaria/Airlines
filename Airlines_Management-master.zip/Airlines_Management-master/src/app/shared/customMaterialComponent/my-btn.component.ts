import { Component } from '@angular/core';

@Component({
  selector: 'my-btn',
  templateUrl: 'my-btn.html',
  styleUrls: [`./my-btn.scss`]
})

export class MyBtnComponent  {
}