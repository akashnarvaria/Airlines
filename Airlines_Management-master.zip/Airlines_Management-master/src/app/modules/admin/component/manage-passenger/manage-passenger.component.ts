import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-manage-passenger',
  templateUrl: './manage-passenger.component.html',
  styleUrls: ['./manage-passenger.component.scss']
})
export class ManagePassengerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
